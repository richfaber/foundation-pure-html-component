# @babel/plugin-transform-json-strings

> Escape U+2028 LINE SEPARATOR and U+2029 PARAGRAPH SEPARATOR in JS strings

See our website [@babel/plugin-transform-json-strings](https://babeljs.io/docs/babel-plugin-transform-json-strings) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-json-strings
```

or using yarn:

```sh
yarn add @babel/plugin-transform-json-strings --dev
```
