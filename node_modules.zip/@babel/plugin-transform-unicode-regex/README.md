# @babel/plugin-transform-unicode-regex

> Compile ES2015 Unicode regex to ES5

See our website [@babel/plugin-transform-unicode-regex](https://babeljs.io/docs/babel-plugin-transform-unicode-regex) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-unicode-regex
```

or using yarn:

```sh
yarn add @babel/plugin-transform-unicode-regex --dev
```
