module.exports = require("./lib/experimental-worker");
