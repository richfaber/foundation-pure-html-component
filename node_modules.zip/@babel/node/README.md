# @babel/node

> Babel command line

See our website [@babel/node](https://babeljs.io/docs/babel-node) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/node
```

or using yarn:

```sh
yarn add @babel/node --dev
```
