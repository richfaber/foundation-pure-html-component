var assertClassBrand = require("./assertClassBrand.js");
function _classCheckPrivateStaticAccess(receiver, classConstructor, returnValue) {
  return assertClassBrand(classConstructor, receiver, returnValue);
}
module.exports = _classCheckPrivateStaticAccess, module.exports.__esModule = true, module.exports["default"] = module.exports;