var assertClassBrand = require("./assertClassBrand.js");
function _classStaticPrivateMethodGet(receiver, classConstructor, method) {
  assertClassBrand(classConstructor, receiver);
  return method;
}
module.exports = _classStaticPrivateMethodGet, module.exports.__esModule = true, module.exports["default"] = module.exports;